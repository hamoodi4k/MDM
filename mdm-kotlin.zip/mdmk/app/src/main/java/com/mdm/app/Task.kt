package com.mdm.app

import org.json.JSONObject

enum class Status { QUEUED, DOWNLOADING, PAUSED, DONE, FAILED, SCHEDULED }

data class Task(
    val id: String,
    val url: String,
    val name: String = "",
    val total: Long = -1,
    val received: Long = 0,
    val segs: Int = 4,
    val resumable: Boolean = false,
    val probed: Boolean = false,
    val status: Status = Status.QUEUED,
    val error: String? = null,
    val at: Long = 0,
    val uri: String = "",
    val speed: Double = 0.0,
    val cookie: String = "",
    val ua: String = "",
    val referer: String = "",
    val custom: String = "",
) {
    val cat get() = Cat.of(name)
    val progress get() = if (total > 0) (received.toFloat() / total).coerceIn(0f, 1f) else 0f

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("url", url).put("name", name).put("total", total)
        .put("received", received).put("segs", segs).put("resumable", resumable)
        .put("probed", probed).put("status", status.ordinal).put("at", at).put("uri", uri)
        .put("cookie", cookie).put("ua", ua).put("referer", referer).put("custom", custom)

    companion object {
        fun from(j: JSONObject) = Task(
            id = j.getString("id"), url = j.getString("url"), name = j.optString("name"),
            total = j.optLong("total", -1), received = j.optLong("received"),
            segs = j.optInt("segs", 4), resumable = j.optBoolean("resumable"),
            probed = j.optBoolean("probed"), status = Status.entries[j.optInt("status")],
            at = j.optLong("at"), uri = j.optString("uri"),
            cookie = j.optString("cookie"), ua = j.optString("ua"), referer = j.optString("referer"), custom = j.optString("custom"),
        )
    }
}

fun fmtBytes(b: Number): String {
    val u = arrayOf("B", "KB", "MB", "GB", "TB")
    var v = b.toDouble(); var i = 0
    while (v >= 1024 && i < u.size - 1) { v /= 1024; i++ }
    return if (i == 0) "${v.toLong()} B" else "%.1f %s".format(v, u[i])
}

enum class Cat(val ar: String, val dir: String, val exts: Set<String>) {
    VIDEO("فيديو", "Videos", setOf("mp4", "mkv", "avi", "mov", "webm", "3gp", "flv", "wmv", "m4v", "ts")),
    AUDIO("صوت", "Music", setOf("mp3", "m4a", "aac", "wav", "flac", "ogg", "opus", "wma")),
    IMAGE("صور", "Images", setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "svg")),
    DOC("مستندات", "Documents", setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "epub", "csv", "rtf", "odt")),
    ARCHIVE("مضغوطات", "Archives", setOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz", "iso")),
    APP("تطبيقات", "Apps", setOf("apk", "xapk", "apks", "aab")),
    OTHER("أخرى", "Other", emptySet());

    companion object {
        fun of(name: String): Cat {
            val e = name.substringAfterLast('.', "").lowercase()
            return entries.firstOrNull { e in it.exts } ?: OTHER
        }
    }
}
