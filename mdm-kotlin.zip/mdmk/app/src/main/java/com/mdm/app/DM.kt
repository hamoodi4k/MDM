package com.mdm.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.URLDecoder
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

/** Errors that retrying cannot fix. */
class Fatal(msg: String) : IOException(msg)
private fun httpErr(c: Int): IOException =
    if (c in 400..499 && c != 408 && c != 429) Fatal("HTTP $c") else IOException("HTTP $c")

/** Download manager: segmented downloads, resume, scheduling, Wi-Fi only. */
object DM {
    private lateinit var ctx: Context
    private lateinit var prefs: SharedPreferences
    val tasks = MutableStateFlow<List<Task>>(emptyList())
    val wifiOnly = MutableStateFlow(false)
    val segs = MutableStateFlow(4)
    val limit = MutableStateFlow(0) // KB/s, 0 = unlimited
    val lock = MutableStateFlow(false)
    val dataCap = MutableStateFlow(0) // MB per day on metered networks, 0 = off
    val mobUsed = MutableStateFlow(0L)
    @Volatile private var metered = false
    private val mobBytes = AtomicLong(0)
    private var mobDay = ""
    private val gate = Any()
    private var nextAt = 0L
    private const val MAX_ACTIVE = 3

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val jobs = ConcurrentHashMap<String, Job>()
    private val counters = ConcurrentHashMap<String, AtomicLong>()
    private val last = HashMap<String, Long>()
    private val lock = Any()
    private var started = false
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()

    fun init(c: Context) {
        if (started) return
        started = true
        ctx = c.applicationContext
        ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel("mdm_done", "اكتمال التحميل", NotificationManager.IMPORTANCE_DEFAULT))
        prefs = ctx.getSharedPreferences("mdm", Context.MODE_PRIVATE)
        wifiOnly.value = prefs.getBoolean("wifi", false)
        segs.value = prefs.getInt("segs", 4)
        limit.value = prefs.getInt("limit", 0)
        lock.value = prefs.getBoolean("lock", false)
        dataCap.value = prefs.getInt("cap", 0)
        mobDay = prefs.getString("mobday", "") ?: ""
        mobBytes.set(prefs.getLong("mobbytes", 0))
        val arr = JSONArray(prefs.getString("tasks", "[]"))
        tasks.value = (0 until arr.length()).map { Task.from(arr.getJSONObject(it)) }.map { t ->
            when {
                t.status == Status.DONE -> t
                else -> t.copy(
                    status = if (t.status == Status.DOWNLOADING) Status.QUEUED else t.status,
                    received = (0 until t.segs).sumOf { File(partsDir(), "${t.id}.p$it").let { f -> if (f.exists()) f.length() else 0L } },
                )
            }
        }
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(n: Network) = onNet()
            override fun onLost(n: Network) = onNet()
            override fun onCapabilitiesChanged(n: Network, c: NetworkCapabilities) = onNet()
        })
        scope.launch { var n = 0; while (true) { delay(500); tick(n++) } }
    }

    // ---------- public API ----------
    fun add(url: String, at: Long = 0, cookie: String = "", ua: String = "", referer: String = "", name: String = "") {
        val t = Task(
            id = UUID.randomUUID().toString(), url = url.trim(), segs = segs.value,
            status = if (at > System.currentTimeMillis()) Status.SCHEDULED else Status.QUEUED, at = at,
            cookie = cookie, ua = ua, referer = referer, custom = name,
        )
        tasks.update { listOf(t) + it }
        save(); pump()
    }

    fun pause(id: String) {
        upd(id) { copy(status = Status.PAUSED, speed = 0.0) }
        jobs[id]?.cancel()
    }

    fun resume(id: String) { upd(id) { copy(status = Status.QUEUED, error = null) }; pump() }

    fun remove(id: String, deleteFile: Boolean) {
        val t = tasks.value.find { it.id == id } ?: return
        jobs[id]?.cancel()
        tasks.update { l -> l.filter { it.id != id } }
        (0 until t.segs).forEach { File(partsDir(), "$id.p$it").delete() }
        if (deleteFile && t.uri.isNotBlank()) runCatching { ctx.contentResolver.delete(Uri.parse(t.uri), null, null) }
        save()
    }

    fun setWifi(v: Boolean) { wifiOnly.value = v; prefs.edit().putBoolean("wifi", v).apply(); onNet() }
    fun setSegs(v: Int) { segs.value = v; prefs.edit().putInt("segs", v).apply() }
    fun setCap(mb: Int) { dataCap.value = mb; prefs.edit().putInt("cap", mb).apply(); onNet() }

    private fun today() = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date())
    private fun rollDay() { val d = today(); if (d != mobDay) { mobDay = d; mobBytes.set(0) } }
    private fun addMobile(k: Int) { rollDay(); mobBytes.addAndGet(k.toLong()) }
    private fun capReached(): Boolean {
        val c = dataCap.value
        if (c <= 0) return false
        rollDay()
        return mobBytes.get() >= c * 1024L * 1024L
    }

    /** Backup: unfinished links + bookmarks (cookies are never exported). */
    fun exportTo(uri: Uri): Boolean = runCatching {
        val root = JSONObject().put("app", "MDM").put("v", 1)
        root.put("tasks", JSONArray(tasks.value.map {
            JSONObject().put("url", it.url).put("name", it.name).put("done", it.status == Status.DONE)
        }))
        root.put("bookmarks", JSONArray(Bookmarks.items.map { JSONObject().put("t", it.first).put("u", it.second) }))
        ctx.contentResolver.openOutputStream(uri)!!.use { it.write(root.toString(2).toByteArray()) }
        true
    }.getOrDefault(false)

    fun importFrom(uri: Uri): Int = runCatching {
        val txt = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes().toString(Charsets.UTF_8) }
        val root = JSONObject(txt)
        val have = tasks.value.map { it.url }.toMutableSet()
        var n = 0
        root.optJSONArray("tasks")?.let { a ->
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val u = o.optString("url")
                if (u.startsWith("http") && u !in have && !o.optBoolean("done")) { add(u, name = o.optString("name")); have.add(u); n++ }
            }
        }
        root.optJSONArray("bookmarks")?.let { a ->
            for (i in 0 until a.length()) a.getJSONObject(i).let { Bookmarks.addIfMissing(it.optString("t"), it.optString("u")) }
        }
        n
    }.getOrDefault(0)

    fun setLock(v: Boolean) { lock.value = v; prefs.edit().putBoolean("lock", v).apply() }
    fun setLimit(kb: Int) { limit.value = kb; prefs.edit().putInt("limit", kb).apply() }

    /** Global bandwidth limiter shared by all segments; returns ms to wait. */
    private fun reserve(bytes: Int): Long {
        val kb = limit.value
        if (kb <= 0) return 0
        synchronized(gate) {
            val now = System.nanoTime()
            val start = maxOf(now, nextAt)
            nextAt = start + bytes * 1_000_000_000L / (kb * 1024L)
            return (start - now) / 1_000_000
        }
    }

    // ---------- internals ----------
    private fun partsDir() = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "parts").apply { mkdirs() }
    private fun get(id: String) = tasks.value.first { it.id == id }
    private fun save() = prefs.edit().putString("tasks", JSONArray(tasks.value.map { it.toJson() }).toString()).apply()
    private fun upd(id: String, f: Task.() -> Task) { tasks.update { l -> l.map { if (it.id == id) it.f() else it } }; save() }

    private fun netOk(): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val c = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return false
        metered = cm.isActiveNetworkMetered
        if (metered && capReached()) return false
        return !wifiOnly.value || c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
            c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    private fun onNet() {
        if (!netOk()) {
            tasks.value.filter { it.status == Status.DOWNLOADING }.forEach { t ->
                upd(t.id) { copy(status = Status.QUEUED, speed = 0.0) }
                jobs[t.id]?.cancel()
            }
        } else pump()
    }

    private fun tick(n: Int) {
        val now = System.currentTimeMillis()
        tasks.update { l ->
            l.map { t ->
                when {
                    t.status == Status.DOWNLOADING -> {
                        val r = counters[t.id]?.get() ?: t.received
                        val prev = last[t.id] ?: r
                        last[t.id] = r
                        t.copy(received = r, speed = (r - prev) * 2.0)
                    }
                    t.status == Status.SCHEDULED && t.at in 1..now -> t.copy(status = Status.QUEUED)
                    else -> t
                }
            }
        }
        pump()
        if (n % 10 == 0) save()
        mobUsed.value = mobBytes.get()
        if (n % 10 == 0) prefs.edit().putString("mobday", mobDay).putLong("mobbytes", mobBytes.get()).apply()
        if (n % 4 == 0 && !netOk()) onNet()
        val busy = tasks.value.any { it.status == Status.DOWNLOADING || it.status == Status.QUEUED || it.status == Status.SCHEDULED }
        if (busy && !DlService.running) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, DlService::class.java))
                DlService.running = true
            } catch (_: Exception) { }
        }
    }

    private fun pump() {
        if (!netOk()) return
        synchronized(lock) {
            var active = tasks.value.count { it.status == Status.DOWNLOADING }
            for (t in tasks.value.filter { it.status == Status.QUEUED }.reversed()) {
                if (active >= MAX_ACTIVE) break
                active++
                upd(t.id) { copy(status = Status.DOWNLOADING, error = null) }
                jobs[t.id] = scope.launch { run(t.id) }
            }
        }
    }

    private suspend fun run(id: String) {
        var attempt = 0
        try {
            while (true) {
                try {
                    download(id)
                    return
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    currentCoroutineContext().ensureActive()
                    attempt++
                    if (e is Fatal || attempt > 5) {
                        upd(id) { copy(status = Status.FAILED, error = e.message ?: e.javaClass.simpleName, speed = 0.0) }
                        return
                    }
                    upd(id) { copy(error = "انقطع الاتصال، إعادة المحاولة $attempt/5…", speed = 0.0) }
                    delay(2000L * attempt)
                }
            }
        } finally {
            jobs.remove(id)
            pump()
        }
    }

    private suspend fun download(id: String) {
        run {
            upd(id) { copy(error = null) }
            var t = get(id)
            if (!t.probed) { probe(t); t = get(id) }
            val n = if (t.resumable && t.total > 1_000_000) t.segs else 1
            val size = if (t.total > 0) (t.total + n - 1) / n else 0L
            val counter = AtomicLong(0)
            counters[id] = counter
            val specs = (0 until n).mapNotNull { i ->
                val f = File(partsDir(), "$id.p$i")
                var have = if (f.exists()) f.length() else 0L
                val s = i * size
                val len = if (t.total > 0) (if (i == n - 1) t.total - s else size) else 0L
                if (!t.resumable && have > 0) { f.delete(); have = 0 }
                if (len > 0 && have > len) { f.delete(); have = 0 }
                counter.addAndGet(have)
                if (len > 0 && have == len) null
                else Triple(f, if (t.resumable) s + have else -1L, if (t.resumable) s + len - 1 else -1L)
            }
            coroutineScope { specs.map { (f, a, b) -> async { segment(t, f, a, b, counter) } }.awaitAll() }
            val uri = merge(t, n)
            val got = counter.get()
            upd(id) { copy(status = Status.DONE, total = if (total > 0) total else got, received = if (total > 0) total else got, uri = uri, speed = 0.0) }
            notifyDone(id)
        }
    }

    private fun Request.Builder.hdr(t: Task) = apply {
        if (t.ua.isNotBlank()) header("User-Agent", t.ua)
        if (t.cookie.isNotBlank()) header("Cookie", t.cookie)
        if (t.referer.isNotBlank()) header("Referer", t.referer)
    }

    private fun notifyDone(id: String) {
        val t = tasks.value.find { it.id == id } ?: return
        runCatching {
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(t.name.substringAfterLast('.', "").lowercase()) ?: "*/*"
            val open = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(t.uri), mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val pi = PendingIntent.getActivity(ctx, id.hashCode(), open, PendingIntent.FLAG_IMMUTABLE)
            val n = NotificationCompat.Builder(ctx, "mdm_done")
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("اكتمل التحميل").setContentText(t.name)
                .setContentIntent(pi).setAutoCancel(true).build()
            NotificationManagerCompat.from(ctx).notify(id.hashCode(), n)
        }
    }

    private fun probe(t: Task) {
        val req = Request.Builder().url(t.url).header("Range", "bytes=0-0").hdr(t).build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw httpErr(r.code)
            val total: Long
            val res: Boolean
            if (r.code == 206) {
                total = r.header("Content-Range")?.substringAfterLast('/')?.toLongOrNull() ?: -1
                res = total > 0
            } else { total = r.body?.contentLength() ?: -1; res = false }
            val cd = r.header("Content-Disposition")
            val fromCd = cd?.let { Regex("filename\\*?=(?:UTF-8'')?\"?([^\";]+)").find(it)?.groupValues?.get(1) }
            var name = fromCd ?: r.request.url.pathSegments.lastOrNull { it.isNotEmpty() } ?: "file"
            name = runCatching { URLDecoder.decode(name, "UTF-8") }.getOrDefault(name)
                .replace(Regex("[\\\\/:*?\"<>|]"), "_")
            if (t.custom.isNotBlank()) {
                val c = t.custom.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
                val ext = name.substringAfterLast('.', "")
                name = if (c.contains('.') || ext.isEmpty()) c else "$c.$ext"
            }
            upd(t.id) { copy(total = total, resumable = res, name = name, probed = true) }
        }
    }

    private suspend fun segment(t: Task, f: File, from: Long, to: Long, counter: AtomicLong) =
        withContext(Dispatchers.IO) {
            val rb = Request.Builder().url(t.url).hdr(t)
            if (from >= 0) rb.header("Range", "bytes=$from-$to")
            val call = client.newCall(rb.build())
            val h = coroutineContext.job.invokeOnCompletion { if (it != null) call.cancel() }
            try {
                call.execute().use { r ->
                    if (!r.isSuccessful) throw httpErr(r.code)
                    if (from >= 0 && r.code != 206) throw Fatal("الخادم لا يدعم التحميل المجزّأ")
                    r.body!!.byteStream().use { inp ->
                        FileOutputStream(f, from > 0).use { out ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                val k = inp.read(buf)
                                if (k < 0) break
                                out.write(buf, 0, k)
                                counter.addAndGet(k.toLong())
                                if (metered) addMobile(k)
                                val w = reserve(k)
                                if (w > 0) delay(w)
                                ensureActive()
                            }
                        }
                    }
                }
            } finally { h.dispose() }
        }

    /** Merge parts straight into Downloads/MDM through MediaStore (no storage permission needed). */
    private fun merge(t: Task, n: Int): String {
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(t.name.substringAfterLast('.', "").lowercase())
            ?: "application/octet-stream"
        val cr = ctx.contentResolver
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, t.name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/MDM/${t.cat.dir}")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: throw IOException("تعذّر إنشاء الملف")
        cr.openOutputStream(uri)!!.use { out ->
            for (i in 0 until n) {
                val p = File(partsDir(), "${t.id}.p$i")
                p.inputStream().use { it.copyTo(out, 256 * 1024) }
                p.delete()
            }
        }
        v.clear(); v.put(MediaStore.Downloads.IS_PENDING, 0)
        cr.update(uri, v, null, null)
        return uri.toString()
    }
}
