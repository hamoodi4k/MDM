package com.mdm.app

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        DM.init(this)
        Bookmarks.init(this)
    }
}
