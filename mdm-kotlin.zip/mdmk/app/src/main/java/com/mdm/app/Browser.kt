package com.mdm.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.material.icons.filled.MoreVert
import org.json.JSONTokener
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

private const val HOME = "https://duckduckgo.com"

class BTab(val web: WebView) {
    var title by mutableStateOf("جديد")
    var url by mutableStateOf("")
    var progress by mutableIntStateOf(100)
}

object BrowserState {
    val tabs = mutableStateListOf<BTab>()
    var cur by mutableIntStateOf(0)
}

object Bookmarks {
    val items = mutableStateListOf<Pair<String, String>>()
    private lateinit var prefs: SharedPreferences

    fun init(c: Context) {
        prefs = c.getSharedPreferences("mdm", Context.MODE_PRIVATE)
        val a = JSONArray(prefs.getString("bm", "[]"))
        items.clear()
        for (i in 0 until a.length()) a.getJSONObject(i).let { items.add(it.getString("t") to it.getString("u")) }
    }

    private fun save() = prefs.edit().putString("bm",
        JSONArray(items.map { JSONObject().put("t", it.first).put("u", it.second) }).toString()).apply()

    fun has(u: String) = items.any { it.second == u }
    fun toggle(t: String, u: String) {
        val i = items.indexOfFirst { it.second == u }
        if (i >= 0) items.removeAt(i) else items.add(0, t.ifBlank { u } to u)
        save()
    }
    fun remove(u: String) { items.removeAll { it.second == u }; save() }
    fun addIfMissing(t: String, u: String) { if (!has(u)) { items.add(t to u); save() } }
}

@SuppressLint("SetJavaScriptEnabled")
fun addTab(c: Context, url: String) {
    val app = c.applicationContext
    val web = WebView(app)
    val tab = BTab(web)
    web.settings.javaScriptEnabled = true
    web.settings.domStorageEnabled = true
    web.webViewClient = object : WebViewClient() {
        override fun onPageStarted(v: WebView, u: String, f: Bitmap?) { tab.url = u }
        override fun onPageFinished(v: WebView, u: String) { tab.url = u; tab.title = v.title ?: u }
    }
    web.webChromeClient = object : WebChromeClient() {
        override fun onProgressChanged(v: WebView, p: Int) { tab.progress = p }
        override fun onReceivedTitle(v: WebView, t: String?) { if (!t.isNullOrBlank()) tab.title = t }
    }
    web.setDownloadListener { link, ua, _, _, _ ->
        if (link.startsWith("http")) {
            DM.add(link, 0, CookieManager.getInstance().getCookie(link) ?: "", ua ?: "", web.url ?: "")
            Toast.makeText(app, "أُضيف إلى التحميلات", Toast.LENGTH_SHORT).show()
        } else Toast.makeText(app, "هذا النوع من الروابط غير مدعوم", Toast.LENGTH_SHORT).show()
    }
    BrowserState.tabs.add(tab)
    BrowserState.cur = BrowserState.tabs.lastIndex
    web.loadUrl(url)
}

fun closeTab(i: Int) {
    val tabs = BrowserState.tabs
    val t = tabs.getOrNull(i) ?: return
    val app = t.web.context
    (t.web.parent as? ViewGroup)?.removeView(t.web)
    t.web.destroy()
    tabs.removeAt(i)
    if (tabs.isEmpty()) addTab(app, HOME)
    BrowserState.cur = BrowserState.cur.coerceIn(0, tabs.lastIndex)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Browser(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val tabs = BrowserState.tabs
    LaunchedEffect(Unit) { if (tabs.isEmpty()) addTab(ctx, HOME) }
    val cur = BrowserState.cur.coerceIn(0, (tabs.size - 1).coerceAtLeast(0))
    val tab = tabs.getOrNull(cur)
    var addr by remember { mutableStateOf("") }
    var showBm by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var links by remember { mutableStateOf<List<String>?>(null) }
    LaunchedEffect(tab, tab?.url) { addr = tab?.url ?: "" }

    fun go(input: String) {
        val s = input.trim()
        if (s.isEmpty()) return
        val u = when {
            s.startsWith("http://") || s.startsWith("https://") -> s
            !s.contains(' ') && s.contains('.') -> "https://$s"
            else -> "https://duckduckgo.com/?q=" + URLEncoder.encode(s, "UTF-8")
        }
        tab?.web?.loadUrl(u)
    }

    BackHandler {
        val w = tab?.web
        if (w != null && w.canGoBack()) w.goBack()
        else if (tabs.size > 1) closeTab(cur)
        else onClose()
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClose) { Text("التحميلات") }
            OutlinedTextField(
                addr, { addr = it }, singleLine = true, modifier = Modifier.weight(1f),
                placeholder = { Text("ابحث أو اكتب رابطاً") },
                textStyle = LocalTextStyle.current.copy(textDirection = TextDirection.Ltr),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { go(addr) }),
            )
            val marked = Bookmarks.has(tab?.url ?: "")
            IconButton({ tab?.let { if (it.url.isNotBlank()) Bookmarks.toggle(it.title, it.url) } }) {
                Icon(if (marked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "إشارة مرجعية",
                    tint = if (marked) Color.Red else LocalContentColor.current)
            }
            Box {
                IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, "المزيد") }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("الإشارات المرجعية") }, onClick = { menu = false; showBm = true })
                    DropdownMenuItem(text = { Text("روابط الصفحة (تحميل متعدد)") }, onClick = {
                        menu = false
                        tab?.web?.let { w -> collectLinks(w) { links = it } }
                    })
                }
            }
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically,
        ) {
            tabs.forEachIndexed { i, t ->
                InputChip(
                    selected = i == cur, onClick = { BrowserState.cur = i },
                    label = { Text(t.title.take(14), maxLines = 1) },
                    trailingIcon = { Icon(Icons.Default.Close, "إغلاق", Modifier.size(16.dp).clickable { closeTab(i) }) },
                )
            }
            IconButton({ addTab(ctx, HOME) }) { Icon(Icons.Default.Add, "تبويب جديد") }
        }
        if (tab != null && tab.progress < 100)
            LinearProgressIndicator(progress = { tab.progress / 100f }, modifier = Modifier.fillMaxWidth())
        if (tab != null) AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { FrameLayout(it) },
            update = { f ->
                if (f.childCount != 1 || f.getChildAt(0) !== tab.web) {
                    f.removeAllViews()
                    (tab.web.parent as? ViewGroup)?.removeView(tab.web)
                    f.addView(tab.web)
                }
            },
            onRelease = { it.removeAllViews() },
        )
    }

    if (showBm) AlertDialog(
        onDismissRequest = { showBm = false },
        title = { Text("الإشارات المرجعية") },
        text = {
            if (Bookmarks.items.isEmpty()) Text("لا توجد إشارات بعد. اضغط على القلب لحفظ الصفحة الحالية.")
            else LazyColumn(Modifier.heightIn(max = 400.dp)) {
                items(Bookmarks.items.toList()) { (t, u) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f).clickable { tab?.web?.loadUrl(u); showBm = false }.padding(vertical = 6.dp)) {
                            Text(t, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
                            Text(u, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp)
                        }
                        IconButton({ Bookmarks.remove(u) }) { Icon(Icons.Default.Delete, "حذف") }
                    }
                }
            }
        },
        confirmButton = { TextButton({ showBm = false }) { Text("إغلاق") } },
    )
    links?.let { LinksDialog(it, tab?.url ?: "", tab?.web?.settings?.userAgentString ?: "") { links = null } }
}

fun nameOf(u: String): String = runCatching { Uri.parse(u).lastPathSegment ?: u }.getOrDefault(u)

fun collectLinks(web: WebView, done: (List<String>) -> Unit) {
    val js = "(function(){var r=[];document.querySelectorAll('a[href],source[src],video[src],audio[src],img[src]')" +
        ".forEach(function(e){r.push(e.href||e.src)});return JSON.stringify(r)})()"
    web.evaluateJavascript(js) { v ->
        val list = try {
            val a = JSONArray(JSONTokener(v).nextValue() as? String ?: "[]")
            (0 until a.length()).map { a.getString(it) }
        } catch (_: Exception) { emptyList() }
        done(list.filter { it.startsWith("http") }.distinct())
    }
}

@Composable
fun LinksDialog(all: List<String>, page: String, ua: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var onlyFiles by remember { mutableStateOf(true) }
    val shown = remember(onlyFiles, all) { if (onlyFiles) all.filter { Cat.of(nameOf(it)) != Cat.OTHER } else all }
    val sel = remember { mutableStateListOf<String>() }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("روابط الصفحة (${shown.size})") },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("الملفات فقط", Modifier.weight(1f))
                    Switch(onlyFiles, { onlyFiles = it; sel.clear() })
                }
                Row {
                    TextButton({ sel.clear(); sel.addAll(shown) }) { Text("تحديد الكل") }
                    TextButton({ sel.clear() }) { Text("إلغاء التحديد") }
                }
                if (shown.isEmpty()) Text("لم يتم العثور على روابط ملفات في هذه الصفحة.")
                else LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(shown) { u ->
                        val toggle = { if (u in sel) sel.remove(u) else sel.add(u); Unit }
                        Row(Modifier.clickable { toggle() }, verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(u in sel, { toggle() })
                            Column(Modifier.weight(1f)) {
                                Text(nameOf(u), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
                                Text(u, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(enabled = sel.isNotEmpty(), onClick = {
                sel.forEach { DM.add(it, 0, CookieManager.getInstance().getCookie(it) ?: "", ua, page) }
                Toast.makeText(ctx, "أُضيف ${sel.size} ملف إلى التحميلات", Toast.LENGTH_SHORT).show()
                onClose()
            }) { Text("تحميل (${sel.size})") }
        },
        dismissButton = { TextButton(onClose) { Text("إلغاء") } },
    )
}
