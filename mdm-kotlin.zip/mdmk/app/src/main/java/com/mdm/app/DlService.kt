package com.mdm.app

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

class DlService : Service() {
    companion object { @Volatile var running = false }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var loop: Job? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("mdm", "MDM", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        startForeground(1, build("MDM", "جاري التحضير…", -1), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        if (loop == null) loop = scope.launch {
            val nm = getSystemService(NotificationManager::class.java)
            var idle = 0
            while (true) {
                delay(1000)
                val l = DM.tasks.value
                val act = l.filter { it.status == Status.DOWNLOADING }
                val busy = l.any { it.status in setOf(Status.DOWNLOADING, Status.QUEUED, Status.SCHEDULED) }
                if (!busy) { if (++idle >= 2) { stopSelf(); break } } else idle = 0
                val title = if (act.isEmpty()) "في الانتظار" else "${act.size} تحميل نشط"
                val text = if (act.isEmpty()) "" else "${fmtBytes(act.sumOf { it.speed })}/ث"
                val pct = if (act.size == 1 && act[0].total > 0) (act[0].progress * 100).toInt() else -1
                nm.notify(1, build(title, text, pct))
            }
        }
        return START_NOT_STICKY
    }

    private fun build(title: String, text: String, pct: Int): Notification =
        NotificationCompat.Builder(this, "mdm")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title).setContentText(text)
            .setOngoing(true).setOnlyAlertOnce(true)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            .apply { if (pct >= 0) setProgress(100, pct, false) }
            .build()

    override fun onDestroy() { running = false; scope.cancel(); super.onDestroy() }
    override fun onBind(i: Intent?): IBinder? = null
}
