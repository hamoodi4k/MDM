package com.mdm.app

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.annotation.SuppressLint
import androidx.compose.foundation.verticalScroll
import android.app.KeyguardManager
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.filled.Search
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.flow.MutableStateFlow
import java.net.URLEncoder
import java.util.Calendar

/** Links received from other apps (share / open). */
object Inbox { val url = MutableStateFlow<String?>(null) }

class MainActivity : ComponentActivity() {
    private var unlocked by mutableStateOf(false)
    private val authLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) unlocked = true else finish()
    }

    private fun needAuth() {
        if (isFinishing || unlocked) return
        val km = getSystemService(KeyguardManager::class.java)
        if (!DM.lock.value || !km.isDeviceSecure) { unlocked = true; return }
        authLauncher.launch(km.createConfirmDeviceCredentialIntent("MDM", "أكّد هويتك لفتح التطبيق"))
    }

    override fun onStart() { super.onStart(); needAuth() }
    override fun onStop() { super.onStop(); if (DM.lock.value) unlocked = false }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) handle(intent)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(Modifier.fillMaxSize()) {
                        if (unlocked) Home()
                        else Box(Modifier.fillMaxSize(), Alignment.Center) { Text("التطبيق مقفل") }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        i ?: return
        val u = when (i.action) {
            Intent.ACTION_SEND -> Regex("https?://\\S+").find(i.getStringExtra(Intent.EXTRA_TEXT) ?: "")?.value
            Intent.ACTION_VIEW -> i.dataString
            else -> null
        }
        if (u != null) Inbox.url.value = u
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Home() {
    val tasks by DM.tasks.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var showSet by remember { mutableStateOf(false) }
    var browser by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf<Cat?>(null) }
    val shared by Inbox.url.collectAsState()
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) perm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(shared) { if (shared != null) browser = false }
    if (browser) { Browser { browser = false }; return }
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("MDM") }, actions = {
                IconButton(onClick = { browser = true }) { Icon(Icons.Default.Search, "المتصفح") }
                IconButton(onClick = { showSet = true }) { Icon(Icons.Default.Settings, "الإعدادات") }
            })
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAdd = true },
                icon = { Icon(Icons.Default.Add, null) },
                text = { Text("تحميل جديد") })
        },
    ) { pad ->
        val cats = Cat.entries.filter { c -> tasks.any { it.cat == c } }
        val shown = if (filter == null) tasks else tasks.filter { it.cat == filter }
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (tasks.isEmpty()) Box(Modifier.fillMaxSize(), Alignment.Center) {
                Text("لا توجد تحميلات\nاضغط «تحميل جديد» لإضافة رابط", textAlign = TextAlign.Center)
            } else {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    FilterChip(filter == null, { filter = null }, label = { Text("الكل (${tasks.size})") })
                    cats.forEach { c ->
                        FilterChip(filter == c, { filter = c }, label = { Text("${c.ar} (${tasks.count { it.cat == c }})") })
                    }
                }
                if (shown.isEmpty()) Box(Modifier.fillMaxSize(), Alignment.Center) { Text("لا توجد ملفات في هذا التصنيف") }
                else LazyColumn(
                    Modifier.weight(1f),
                    contentPadding = PaddingValues(12.dp, 8.dp, 12.dp, 96.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) { items(shown, key = { it.id }) { TaskCard(it) } }
            }
        }
    }
    if (showAdd || shared != null) AddDialog(shared ?: "") { showAdd = false; Inbox.url.value = null }
    if (showSet) SettingsDialog { showSet = false }
}

@Composable
fun TaskCard(t: Task) {
    val ctx = LocalContext.current
    val st = when (t.status) {
        Status.DOWNLOADING -> t.error ?: "${fmtBytes(t.speed)}/ث"
        Status.PAUSED -> "متوقف"
        Status.DONE -> "مكتمل • ${t.cat.ar}"
        Status.FAILED -> "فشل: ${t.error ?: ""}"
        Status.SCHEDULED -> "مجدول"
        Status.QUEUED -> "في الانتظار"
    }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(t.name.ifEmpty { t.url }, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (t.status != Status.DONE) {
                if (t.total > 0) LinearProgressIndicator(progress = { t.progress }, modifier = Modifier.fillMaxWidth())
                else if (t.status == Status.DOWNLOADING) LinearProgressIndicator(Modifier.fillMaxWidth())
            }
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${fmtBytes(t.received)}${if (t.total > 0) " / ${fmtBytes(t.total)}" else ""}  •  $st",
                    fontSize = 12.sp, maxLines = 2, modifier = Modifier.weight(1f))
                when (t.status) {
                    Status.DOWNLOADING -> TextButton({ DM.pause(t.id) }) { Text("إيقاف") }
                    Status.PAUSED, Status.FAILED -> TextButton({ DM.resume(t.id) }) { Text("استئناف") }
                    Status.DONE -> TextButton({
                        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(t.name.substringAfterLast('.', "").lowercase()) ?: "*/*"
                        try {
                            ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(t.uri), mime)
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                        } catch (_: Exception) { Toast.makeText(ctx, "لا يوجد تطبيق لفتح الملف", Toast.LENGTH_SHORT).show() }
                    }) { Text("فتح") }
                    else -> {}
                }
                IconButton({ DM.remove(t.id, t.status == Status.DONE) }) { Icon(Icons.Default.Delete, "حذف") }
            }
        }
    }
}

@Composable
fun AddDialog(initial: String = "", onClose: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    var url by remember { mutableStateOf(initial.ifEmpty { clip.getText()?.text?.takeIf { it.startsWith("http") } ?: "" }) }
    var at by remember { mutableStateOf(0L) }
    var custom by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("إضافة تحميل") },
        text = {
            Column {
                OutlinedTextField(url, { url = it }, singleLine = true, placeholder = { Text("https://...") },
                    textStyle = LocalTextStyle.current.copy(textDirection = TextDirection.Ltr))
                OutlinedTextField(custom, { custom = it }, singleLine = true, placeholder = { Text("اسم الملف (اختياري)") })
                Row {
                    TextButton({ url = clip.getText()?.text ?: "" }) { Text("لصق") }
                    TextButton({
                        val c = Calendar.getInstance()
                        DatePickerDialog(ctx, { _, y, m, d ->
                            TimePickerDialog(ctx, { _, h, mi ->
                                at = Calendar.getInstance().apply { set(y, m, d, h, mi, 0) }.timeInMillis
                            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
                        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                    }) { Text(if (at == 0L) "جدولة" else java.text.SimpleDateFormat("MM/dd HH:mm", java.util.Locale.US).format(at)) }
                }
            }
        },
        confirmButton = {
            Button({ if (url.trim().startsWith("http")) { DM.add(url, at, name = custom); onClose() } }) { Text("ابدأ") }
        },
        dismissButton = { TextButton(onClose) { Text("إلغاء") } },
    )
}

@Composable
fun SettingsDialog(onClose: () -> Unit) {
    val wifi by DM.wifiOnly.collectAsState()
    val segs by DM.segs.collectAsState()
    val limit by DM.limit.collectAsState()
    val lock by DM.lock.collectAsState()
    val cap by DM.dataCap.collectAsState()
    val used by DM.mobUsed.collectAsState()
    val ctx = LocalContext.current
    val exp = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u ->
        if (u != null) Toast.makeText(ctx, if (DM.exportTo(u)) "تم التصدير" else "فشل التصدير", Toast.LENGTH_SHORT).show()
    }
    val imp = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) Toast.makeText(ctx, "تم استيراد ${DM.importFrom(u)} تحميل", Toast.LENGTH_SHORT).show()
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("الإعدادات") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Wi-Fi فقط", Modifier.weight(1f))
                    Switch(wifi, { DM.setWifi(it) })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("قفل التطبيق (بصمة / PIN / نمط)", Modifier.weight(1f))
                    Switch(lock, { on ->
                        val km = ctx.getSystemService(KeyguardManager::class.java)
                        if (on && !km.isDeviceSecure)
                            Toast.makeText(ctx, "فعّل قفل الشاشة من إعدادات الجهاز أولاً", Toast.LENGTH_LONG).show()
                        else DM.setLock(on)
                    })
                }
                Spacer(Modifier.height(12.dp))
                Text("عدد الأجزاء لكل ملف")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(1, 2, 4, 8, 16).forEach { n ->
                        FilterChip(segs == n, { DM.setSegs(n) }, label = { Text("$n") })
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("تحديد سرعة التحميل")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(0 to "بلا حد", 256 to "256 KB/s", 512 to "512 KB/s", 1024 to "1 MB/s", 2048 to "2 MB/s", 5120 to "5 MB/s").forEach { (kb, label) ->
                        FilterChip(limit == kb, { DM.setLimit(kb) }, label = { Text(label) })
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("حد البيانات اليومي على شبكة الجوال (استُخدم اليوم: ${fmtBytes(used)})")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(0 to "بلا حد", 100 to "100 MB", 500 to "500 MB", 1024 to "1 GB", 2048 to "2 GB").forEach { (mb, label) ->
                        FilterChip(cap == mb, { DM.setCap(mb) }, label = { Text(label) })
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton({ exp.launch("mdm-backup.json") }) { Text("تصدير القائمة") }
                    OutlinedButton({ imp.launch(arrayOf("*/*")) }) { Text("استيراد القائمة") }
                }
            }
        },
        confirmButton = { TextButton(onClose) { Text("تم") } },
    )
}

